Slide Demo

* Demonstration of Slide App
* Friday, Nov 16, 2018
* by Daniel Herrera

![Bear Logo](Bear.png)


--

#### Development Process
* Slides can be easily constructed 
* [Brain Home](index.php)

---

#### Test Slide 1
* Content

--

#### Test 1 Sub slide
* Content

---

#### Test Slide 2
* Content

--

#### Test 2 Sub slide
* Content