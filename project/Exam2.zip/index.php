<?php

    
    // Start the page
    require_once 'views.php';
    require_once 'files.php';
    require_once 'album.php';


    // Log the page load
    require_once 'log.php';
    $log->log_page("Exam 2");

    $site_title = 'Exam 2';
    $page_title = 'Exam 2';
    begin_page($site_title, $page_title);


    // Page Content

    echo '<p><a href="pagelog.php">Page log</a></p>';
    echo '<p><a href="addalbum.php">Add Album</a></p>';


    $album->show_albums();


    end_page();
?>
